TOKEN = '6001935979:AAGeCb80dln06M_R5G5uIelGbxrpXxsVZhU'
API_KEY = '1c8c9d0103a5423e9d74850970bddf97'
API_URL = 'https://openexchangerates.org/api/latest.json'
api_key = '1c8c9d0103a5423e9d74850970bddf97'